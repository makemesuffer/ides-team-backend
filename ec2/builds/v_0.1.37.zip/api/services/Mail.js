const fs = require('fs')
const nodemailer = require('nodemailer')
const { SES_USER, SES_PASS, NODE_ENV } = process.env

module.exports = {
    send: async function (to, subject, text) {
        return new Promise((resolve) => {
            const from = ''

            const transporter = nodemailer.createTransport({
                port: 465,
                host: '',
                secure: true,
                auth: {
                    user: NODE_ENV === 'development' ? fs.readFileSync('./certs/sesUser.txt') : SES_USER,
                    pass: NODE_ENV === 'development' ? fs.readFileSync('./certs/sesPass.txt') : SES_PASS
                },
                debug: true
            })

            transporter.sendMail({ from, to, subject, text }, (e) => {
                if (e) resolve({ success: false, reason: e })
                resolve({ success: true })
            })
        })
    },

    reports: sails.config.corpMail.reports
}