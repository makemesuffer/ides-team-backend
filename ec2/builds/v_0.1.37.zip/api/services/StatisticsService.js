module.exports = {
    disciplineProgress: async () => {
        const data = {}

        return { success: true, reason: { data } }
    },
    attendance: async () => {
        const data = {}

        return { success: true, reason: { data } }
    },
    userRating: async () => {
        const data = {}

        return { success: true, reason: { data } }
    },
    getMeta: async () => {
        const data = {}

        return { success: true, reason: { data } }
    }
}