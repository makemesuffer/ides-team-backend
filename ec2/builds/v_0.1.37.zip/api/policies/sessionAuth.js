module.exports = function (req, res, next) {
    const locale = Locale('markers')

    if (req.session.authenticated) {
        return next()
    }

    return res.forbidden(locale.youAreNotPermittedToPerformThisAction)
}