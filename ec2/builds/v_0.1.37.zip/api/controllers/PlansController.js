module.exports = {

    create: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { plan } = req.body

            if (plan) {
                const { success: valid, reason: checks } = await Plans.validateCreate(req, plan)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const record = await Plans.create(plan)
                return res.created({ planId: record.planId })
            }

            return res.badRequest({ missingProps: 'plan', marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    },

    list: async (req, res) => {
        try {
            const locale = Locale('markers')

            const query = JSON.parse(req.params.query || '{"filter":{}}')
            const { success: valid, reason: checks } = await Plans.validateList(req, query)
            if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

            const { success, reason } = await Plans.fetch(query)
            if (!success) return res.badRequest(reason)

            return res.ok(true, reason)
        } catch (e) {
            return res.error(e)
        }
    },

    update: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { filter, props } = req.body

            const updateProps = ['filter', 'props']
            const missingProps = updateProps.filter(item => !(item in req.body))

            if (!missingProps.length) {
                const { success: valid, reason: checks } = await Plans.validateUpdate(req, filter, props)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const { success, reason } = await Plans.fillIn(filter, props)
                if (!success) return res.badRequest(reason)
                return res.ok(true, reason)
            }

            return res.badRequest({ missingProps, marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    },

    delete: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { planId } = req.params

            if (planId) {
                const { success: valid, reason: checks } = await Plans.validateDestroy(req, planId)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const result = await Plans.destroy({ planId })
                if (!result.length) return res.badRequest({ marker: locale.noRecordsFound })

                return res.ok(true, { marker: locale.resourceHasBeenRemoved })
            }

            return res.badRequest({ missingProps: ['planId'], marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    }

}