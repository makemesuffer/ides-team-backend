module.exports = {

    create: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { catalogue } = req.body

            if (catalogue) {
                const { success: valid, reason: checks } = await Catalogues.validateCreate(req, catalogue)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const record = await Catalogues.create(catalogue)
                return res.created({ catalogueId: record.catalogueId })
            }

            return res.badRequest({ missingProps: 'catalogue', marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    },

    list: async (req, res) => {
        try {
            const locale = Locale('markers')

            const query = JSON.parse(req.params.query || '{"filter":{}}')
            const { success: valid, reason: checks } = await Catalogues.validateList(req, query)
            if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

            const { success, reason } = await Catalogues.fetch(query)
            if (!success) return res.badRequest(reason)

            return res.ok(true, reason)
        } catch (e) {
            return res.error(e)
        }
    },

    update: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { filter, props } = req.body

            const updateProps = ['filter', 'props']
            const missingProps = updateProps.filter(item => !(item in req.body))

            if (!missingProps.length) {
                const { success: valid, reason: checks } = await Catalogues.validateUpdate(req, filter, props)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const { success, reason } = await Catalogues.fillIn(filter, props)
                if (!success) return res.badRequest(reason)
                return res.ok(true, reason)
            }

            return res.badRequest({ missingProps, marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    },

    delete: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { catalogueId } = req.params

            if (catalogueId) {
                const { success: valid, reason: checks } = await Catalogues.validateDestroy(req, catalogueId)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const result = await Catalogues.destroy({ catalogueId })
                if (!result.length) return res.badRequest({ marker: locale.noRecordsFound })

                return res.ok(true, { marker: locale.resourceHasBeenRemoved })
            }

            return res.badRequest({ missingProps: ['catalogueId'], marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    }

}