module.exports = {

    create: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { account } = req.body

            if (account) {
                const { success: valid, reason: checks } = await Accounts.validateCreate(req, account)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const record = await Accounts.create(account)
                return res.created({ accountId: record.accountId })
            }

            return res.badRequest({ missingProps: 'account', marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    },

    list: async (req, res) => {
        try {
            const locale = Locale('markers')

            const query = JSON.parse(req.params.query || '{"filter":{}}')
            const { success: valid, reason: checks } = await Accounts.validateList(req, query)
            if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

            const { success, reason } = await Accounts.fetch(query)
            if (!success) return res.badRequest(reason)

            return res.ok(true, reason)
        } catch (e) {
            return res.error(e)
        }
    },

    update: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { filter, props } = req.body

            const updateProps = ['filter', 'props']
            const missingProps = updateProps.filter(item => !(item in req.body))

            if (!missingProps.length) {
                const { success: valid, reason: checks } = await Accounts.validateUpdate(req, filter, props)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const { success, reason } = await Accounts.fillIn(filter, props)
                if (!success) return res.badRequest(reason)

                if (
                    filter.accountId && 
                    filter.accountId === req.session.authenticated.accountId
                ) req.session.authenticated = reason
                
                return res.ok(true, reason)
            }

            return res.badRequest({ missingProps, marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    },

    delete: async (req, res) => {
        try {
            const locale = Locale('markers')
            const { accountId } = req.params

            if (accountId) {
                const { success: valid, reason: checks } = await Accounts.validateDestroy(req, accountId)
                if (!valid) return res.badRequest({ details: checks, marker: locale.requestValidationFailed })

                const result = await Accounts.destroy({ accountId })
                if (!result.length) return res.badRequest({ marker: locale.noRecordsFound })

                return res.ok(true, { marker: locale.resourceHasBeenRemoved })
            }

            return res.badRequest({ missingProps: ['accountId'], marker: locale.requestMissingRequiredProps })
        } catch (e) {
            return res.error(e)
        }
    }

}