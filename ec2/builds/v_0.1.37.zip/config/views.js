module.exports.views = {
    engine: 'pug',
    layout: 'false',
    partials: false
}