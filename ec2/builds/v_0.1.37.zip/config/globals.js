const _ = require('lodash')
const Constants = require('./constants.js')

module.exports.globals = {
    _,
    Constants
}