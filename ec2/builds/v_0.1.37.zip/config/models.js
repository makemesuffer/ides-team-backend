module.exports.models = {

    connection: 'mongo',

    migrate: 'safe',

    schema: false,

}
