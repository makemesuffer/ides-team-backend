module.exports.cors = {
    allRoutes: true,
    origin: '*',
    headers: 'content-type, Authorization'
}