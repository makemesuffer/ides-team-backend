module.exports.corpMail = {
    reports: ''
}