const en = require('./en.js')
const ru = require('./ru.js')
const markers = require('./markers.js')

module.exports = { en, ru, markers }
