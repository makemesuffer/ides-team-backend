module.exports = {
    // russia
    ru: {
        countryCode: 'ru',
        countryCodePhone: '+7',
        countryPhoneNumberLength: '12',
        currencySymbol: '₽',
        currencyCode: 'RUB',
        regionName: 'ru',
    }
}
